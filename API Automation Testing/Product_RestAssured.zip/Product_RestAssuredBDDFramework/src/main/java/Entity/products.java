package Entity;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class products {
	
	private String produt_Name;
	
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int product_price;

	private String product_info;
	private String product_sellerName;
	
	private Order order;  
	
	private String buyerFirstName;
	private String buyerLastName;
	private String buyer_DelivaryAddress;
	private String buyer_EmailId;
	
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private long buyer_MobileNumber;

	public String getProdut_Name() {
		return produt_Name;
	}

	public void setProdut_Name(String produt_Name) {
		this.produt_Name = produt_Name;
	}

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public String getProduct_info() {
		return product_info;
	}

	public void setProduct_info(String product_info) {
		this.product_info = product_info;
	}

	public String getProduct_sellerName() {
		return product_sellerName;
	}

	public void setProduct_sellerName(String product_sellerName) {
		this.product_sellerName = product_sellerName;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getBuyer_DelivaryAddress() {
		return buyer_DelivaryAddress;
	}

	public void setBuyer_DelivaryAddress(String buyer_DelivaryAddress) {
		this.buyer_DelivaryAddress = buyer_DelivaryAddress;
	}

	public String getBuyer_EmailId() {
		return buyer_EmailId;
	}

	public void setBuyer_EmailId(String buyer_EmailId) {
		this.buyer_EmailId = buyer_EmailId;
	}

	public long getBuyer_MobileNumber() {
		return buyer_MobileNumber;
	}

	public void setBuyer_MobileNumber(long buyer_MobileNumber) {
		this.buyer_MobileNumber = buyer_MobileNumber;
	}
}

	