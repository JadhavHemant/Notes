package Entity;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Order {

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int order_id;
	private String order_location;
	private String order_type;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private int order_tokeId;
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public String getOrder_location() {
		return order_location;
	}
	public void setOrder_location(String order_location) {
		this.order_location = order_location;
	}
	public String getOrder_type() {
		return order_type;
	}
	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}
	public int getOrder_tokeId() {
		return order_tokeId;
	}
	public void setOrder_tokeId(int order_tokeId) {
		this.order_tokeId = order_tokeId;
	}

}
