package StepApi;

import java.io.File;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import Entity.products;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class productStepApi {
	RequestSpecification httpReuest;
	String requestbody;
	Response response;
	String responseBody;
	static String id ;

	@Given("user get the Request Specfication Interface Object")
	public void user_get_the_request_specfication_interface_object() {

		httpReuest = RestAssured.given();

	}

	@Given("user configure Base URI")
	public void user_configure_base_uri() {

		httpReuest.baseUri("http://localhost:4000/");
	}

	@Given("user add request header as {string} key and {string} value")
	public void user_add_request_header_as_key_and_value(String key, String value) {
		httpReuest.header(key, value);

	}

	@Given("user create Request body using json node name as {string}")
	public void user_create_request_body_using_json_node_name_as(String jsonNodeName)
			throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		File file = new File(System.getProperty("user.dir") + "//src//test//resources//Product.json");
		JsonNode jsonNode = mapper.readTree(file);
		products prod = mapper.treeToValue(jsonNode.get(jsonNodeName), products.class);
		requestbody = mapper.writeValueAsString(prod);

	}

	@Given("user add reuest body to HTTP Reuest")
	public void user_add_reuest_body_to_http_reuest() {
		httpReuest.body(requestbody);

	}

	@When("user select HTTP {string} Request")
	public void user_select_http_request(String ReuestType) {

		if (ReuestType.equalsIgnoreCase("Post")) {
			response = httpReuest.post("products");
		}
		else if(ReuestType.equalsIgnoreCase("Put"))
		{
			 response=httpReuest.put("products/"+id);
		}

		else if(ReuestType.equalsIgnoreCase("Patch"))
		{
			 response=httpReuest.patch("products/"+id);
		}
		else if(ReuestType.equalsIgnoreCase("Get"))
		{
			response=httpReuest.get("products/"+id);
		}
		else if(ReuestType.equalsIgnoreCase("Delete"))
		{
			response=httpReuest.delete("products/"+id);
		}
	}

	@Then("user capture status code")
	public void user_capture_status_code() {
		System.out.println(response.statusCode());
	}

	@Then("user capture status line")
	public void user_capture_status_line() {
		System.out.println(response.statusLine());
	}

	@Then("user capture response time")
	public void user_capture_response_time() {
		System.out.println(response.time());

	}

	@Then("user capture response body")
	public void user_capture_response_body() {
		 responseBody = response.body().asString();
		System.out.println(responseBody);
	}

	@Then("user capture header")
	public void user_capture_header() {
		System.out.println(response.headers());
	}

	@Then("user capture id from Response body")
	public void user_capture_id_from_response_body() {
		JsonPath jsonpath = new JsonPath(responseBody);
		 id = jsonpath.getString("id");
		System.out.println(id);

	}

}
