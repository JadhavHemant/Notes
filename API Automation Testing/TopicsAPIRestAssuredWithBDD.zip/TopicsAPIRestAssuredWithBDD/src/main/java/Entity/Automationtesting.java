package Entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

//@Getter
//@Setter
//@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Automationtesting {

	@JsonProperty(value = "platform")
	private String platform;

	@JsonProperty(value = "uIAutomation")
	private String uIAutomation;

	@JsonProperty(value = "aPIAutomation")
	private String aPIAutomation;

	@JsonProperty(value = "databaseAutomation")
	private String databaseAutomation;

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getuIAutomation() {
		return uIAutomation;
	}

	public void setuIAutomation(String uIAutomation) {
		this.uIAutomation = uIAutomation;
	}

	public String getaPIAutomation() {
		return aPIAutomation;
	}

	public void setaPIAutomation(String aPIAutomation) {
		this.aPIAutomation = aPIAutomation;
	}

	public String getDatabaseAutomation() {
		return databaseAutomation;
	}

	public void setDatabaseAutomation(String databaseAutomation) {
		this.databaseAutomation = databaseAutomation;
	}

}
