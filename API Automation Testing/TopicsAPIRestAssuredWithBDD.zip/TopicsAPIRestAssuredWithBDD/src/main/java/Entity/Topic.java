package Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

//@Getter()
//@Setter()
//@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Topic {

	@JsonProperty(value = "student_name")
	private String student_name;

	@JsonProperty(value = "emailId")
	private String emailId;

	@JsonProperty(value = "manualTesting")
	private List<String> manualTesting;

	@JsonProperty(value = "automationtesting")
	private Automationtesting automationtesting;

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public List<String> getManualTesting() {
		return manualTesting;
	}

	public void setManualTesting(List<String> manualTesting) {
		this.manualTesting = manualTesting;
	}

	public Automationtesting getAutomationtesting() {
		return automationtesting;
	}

	public void setAutomationtesting(Automationtesting automationtesting) {
		this.automationtesting = automationtesting;
	}

}
