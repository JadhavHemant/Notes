package Steps;

import java.io.File;

import org.hamcrest.Matchers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import Entity.Topic;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class TopicsAPI {
	RequestSpecification httpRequest;
	static Topic topic;

	String requestBody;
	Response response;
	static String topicId;
	ValidatableResponse validateResponse;

	@Given("user configure base URI in rest Assured")
	public void user_configure_base_uri_in_rest_assured() {
		RestAssured.baseURI = "http://localhost:8000/topics";
	}

	@Given("user get the Request Specification interface object")
	public void user_get_the_request_specification_interface_object() {
		httpRequest = RestAssured.given();

	}

	@Given("user add request {string} and {string} headers")
	public void user_add_request_and_headers(String key, String value) {
		httpRequest.header(key, value);
	}

	@Given("user create Request body using json node name as {string}")
	public void user_create_request_body_using_json_node_name_as(String JsonNodeName) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		File f = new File(System.getProperty("user.dir") + "//src//test//resources//topicTestData.json");
		JsonNode jsonNode = mapper.readTree(f);
		topic = mapper.treeToValue(jsonNode.get(JsonNodeName), Topic.class);

		requestBody = mapper.writeValueAsString(topic);

	}

	@Given("user add request body to HTTP Request")
	public void user_add_request_body_to_http_request() {
		httpRequest.body(requestBody);
	}

	@When("user select HTTP {string} request")
	public void user_select_http_request(String RequestType) {

		if (RequestType.equalsIgnoreCase("POST")) {
			response = httpRequest.post();
		} else if (RequestType.equalsIgnoreCase("GET")) {
			response = httpRequest.get(topicId);
		} else if (RequestType.equalsIgnoreCase("PUT")) {
			response = httpRequest.put(topicId);
		} else if (RequestType.equalsIgnoreCase("PATCH")) {
			response = httpRequest.patch(topicId);
		} else if (RequestType.equalsIgnoreCase("DELETE")) {
			response = httpRequest.delete(topicId);
		}

	}

	@Then("user get the Validatable response interface object")
	public void user_get_the_validatable_response_interface_object() {
		validateResponse = response.then().assertThat();

	}

	@Then("user validate status code as {int}")
	public void user_validate_status_code_as(Integer code) {

		validateResponse.statusCode(Matchers.equalTo(code));
	}

	@Then("user validate status line as {string}")
	public void user_validate_status_line_as(String line) {

		validateResponse.statusLine(Matchers.containsString(line));
	}

	@Then("user validate response time should be below {int} ms")
	public void user_validate_response_time_should_be_below_ms(Integer time) {

		validateResponse.time(Matchers.lessThan((long) time));
	}

	@Then("user validate the email id from response body")
	public void user_validate_the_email_id_from_response_body() {

		validateResponse.body("emailId", Matchers.equalTo(topic.getEmailId()));
	}

	@Then("user validate array value from respons body")
	public void user_validate_array_value_from_respons_body() {
		validateResponse.body("manualTesting", Matchers.hasItem(topic.getManualTesting().get(3)));

	}

	@Then("user validate nested aPIAutomation json values from response body")
	public void user_validate_nested_a_pi_automation_json_values_from_response_body() {

		validateResponse.body("automationtesting.aPIAutomation", Matchers.equalTo(topic.getAutomationtesting().getaPIAutomation()));
	}

	@Then("user validate {string} key and value is {string} in response header")
	public void user_validate_key_and_value_is_in_response_header(String key, String value) {
		validateResponse.header(key, Matchers.equalTo(value));
	}

	@Then("user print all response log")
	public void user_print_all_response_log() {
		validateResponse.log().all();
		System.err.println("-------------------------------------------------------------------------");
	}

	@Then("user capture id from response body")
	public void user_capture_id_from_response_body() {
		topicId= response.getBody().jsonPath().getString("id");
		
		
	}

}
